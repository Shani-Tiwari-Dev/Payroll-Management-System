from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from employees.models import Employee
from attendance.models import Attendance
from payroll.models import Payroll


# ─── Role guard decorator ────────────────────────────────────────────────────

def role_required(role):
    def decorator(view_func):
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('/')
            if not hasattr(request.user, 'userprofile'):
                return render(request, 'no_profile.html', {
                    'username': request.user.username
                })
            if request.user.userprofile.role != role:
                return redirect('/dashboard/')
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


# ─── Auth ────────────────────────────────────────────────────────────────────

def login_view(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('/dashboard/')
        else:
            error = 'Invalid username or password.'
    return render(request, 'login.html', {'error': error})


def logout_view(request):
    logout(request)
    return redirect('/')


# ─── Dashboard router ─────────────────────────────────────────────────────────

@login_required
def dashboard_redirect(request):
    # If this user has no UserProfile, show a friendly error — never redirect to /admin/
    if not hasattr(request.user, 'userprofile'):
        return render(request, 'no_profile.html', {
            'username': request.user.username
        })

    role = request.user.userprofile.role
    if role == 'ADMIN':
        return redirect('/admin-dashboard/')
    elif role == 'HR':
        return redirect('/hr-dashboard/')
    elif role == 'EMPLOYEE':
        return redirect('/employee-dashboard/')

    # Unknown role — show error
    return render(request, 'no_profile.html', {
        'username': request.user.username,
        'error': f'Unknown role "{role}". Please contact the system administrator.'
    })


# ─── Admin dashboard ──────────────────────────────────────────────────────────

@login_required
@role_required('ADMIN')
def admin_dashboard(request):
    today = timezone.now().date()
    employees = Employee.objects.all()
    total_employees = employees.count()

    total_payrolls = Payroll.objects.count()
    total_amount = sum(p.net_salary for p in Payroll.objects.all())

    present_today = Attendance.objects.filter(date=today, status='PRESENT').count()
    total_today   = Attendance.objects.filter(date=today).count()
    attendance_rate = round((present_today / total_today * 100) if total_today else 0)

    recent_employees = employees.order_by('-date_joined')[:10]

    return render(request, 'admin_dashboard.html', {
        'total_employees':  total_employees,
        'total_payrolls':   total_payrolls,
        'total_amount':     total_amount,
        'attendance_rate':  attendance_rate,
        'recent_employees': recent_employees,
    })


# ─── HR dashboard ─────────────────────────────────────────────────────────────

@login_required
@role_required('HR')
def hr_dashboard(request):
    today  = timezone.now().date()
    month  = today.month
    year   = today.year

    employees = Employee.objects.all()

    present_today = Attendance.objects.filter(date=today, status='PRESENT').count()
    on_leave      = Attendance.objects.filter(date=today, status='LEAVE').count()
    absent_today  = Attendance.objects.filter(date=today, status='ABSENT').count()

    monthly = Attendance.objects.filter(date__month=month, date__year=year)
    total_m = monthly.count()
    present_count = round(monthly.filter(status='PRESENT').count() / total_m * 100) if total_m else 0
    absent_count  = round(monthly.filter(status='ABSENT').count()  / total_m * 100) if total_m else 0
    leave_count   = round(monthly.filter(status='LEAVE').count()   / total_m * 100) if total_m else 0

    payrolls         = Payroll.objects.filter(month=month, year=year)
    payrolls_count   = payrolls.count()
    total_basic      = sum(p.basic_salary  for p in payrolls)
    total_hra        = sum(p.hra           for p in payrolls)
    total_deductions = sum(p.deductions    for p in payrolls)
    total_net        = sum(p.net_salary    for p in payrolls)

    return render(request, 'hr_dashboard.html', {
        'employees':        employees,
        'total_employees':  employees.count(),
        'present_today':    present_today,
        'on_leave':         on_leave,
        'absent_today':     absent_today,
        'present_count':    present_count,
        'absent_count':     absent_count,
        'leave_count':      leave_count,
        'payrolls_count':   payrolls_count,
        'total_basic':      total_basic,
        'total_hra':        total_hra,
        'total_deductions': total_deductions,
        'total_net':        total_net,
    })


# ─── Employee dashboard ───────────────────────────────────────────────────────

@login_required
@role_required('EMPLOYEE')
def employee_dashboard(request):
    profile = request.user.userprofile
    if not profile.employee:
        return render(request, 'employee_dashboard.html', {
            'error': 'Your account is not linked to an employee record. Please contact HR.'
        })
    employee   = profile.employee
    payrolls   = Payroll.objects.filter(employee=employee).order_by('-year', '-month')
    attendance = Attendance.objects.filter(employee=employee).order_by('-date')[:30]
    return render(request, 'employee_dashboard.html', {
        'employee':   employee,
        'payrolls':   payrolls,
        'attendance': attendance,
    })
