from django.urls import path
from .views import (
    login_view,
    logout_view,
    dashboard_redirect,
    admin_dashboard,
    hr_dashboard,
    employee_dashboard,
)

urlpatterns = [
    path('',                    login_view,         name='login'),
    path('dashboard/',          dashboard_redirect, name='dashboard'),
    path('admin-dashboard/',    admin_dashboard,    name='admin_dashboard'),
    path('hr-dashboard/',       hr_dashboard,       name='hr_dashboard'),
    path('employee-dashboard/', employee_dashboard, name='employee_dashboard'),
    path('logout/',             logout_view,        name='logout'),
]
