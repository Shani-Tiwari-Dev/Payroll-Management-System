from django.urls import path
from .views import employee_list, employee_add, employee_edit

urlpatterns = [
    path('',           employee_list, name='employee_list'),
    path('add/',       employee_add,  name='employee_add'),
    path('<int:pk>/edit/', employee_edit, name='employee_edit'),
]
