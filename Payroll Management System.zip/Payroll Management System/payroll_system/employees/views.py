from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from accounts.views import role_required
from .models import Employee


@login_required
@role_required('HR')
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, 'employee_list.html', {'employees': employees})


@login_required
@role_required('HR')
def employee_add(request):
    if request.method == 'POST':
        try:
            Employee.objects.create(
                name=request.POST['name'],
                email=request.POST['email'],
                department=request.POST['department'],
                designation=request.POST['designation'],
                employee_type=request.POST.get('employee_type', 'FULL_TIME'),
                date_joined=request.POST['date_joined'],
                basic_salary=request.POST['basic_salary'],
                hra=request.POST['hra'],
                bonus=request.POST.get('bonus', 0),
            )
            messages.success(request, 'Employee added successfully.')
            return redirect('employee_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'employee_form.html', {'action': 'Add'})


@login_required
@role_required('HR')
def employee_edit(request, pk):
    emp = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        try:
            emp.name          = request.POST['name']
            emp.email         = request.POST['email']
            emp.department    = request.POST['department']
            emp.designation   = request.POST['designation']
            emp.employee_type = request.POST.get('employee_type', emp.employee_type)
            emp.date_joined   = request.POST['date_joined']
            emp.basic_salary  = request.POST['basic_salary']
            emp.hra           = request.POST['hra']
            emp.bonus         = request.POST.get('bonus', 0)
            emp.save()
            messages.success(request, 'Employee updated.')
            return redirect('employee_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'employee_form.html', {'action': 'Edit', 'employee': emp})
