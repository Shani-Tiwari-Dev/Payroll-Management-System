from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from accounts.views import role_required
from employees.models import Employee
from .models import Attendance


@login_required
@role_required('HR')
def attendance_list(request):
    """HR: view all attendance records, filterable by date."""
    date_filter = request.GET.get('date', str(timezone.now().date()))
    try:
        from datetime import date
        filter_date = date.fromisoformat(date_filter)
    except ValueError:
        filter_date = timezone.now().date()

    records = Attendance.objects.filter(date=filter_date).select_related('employee')
    employees = Employee.objects.all()

    return render(request, 'attendance_list.html', {
        'records':      records,
        'filter_date':  filter_date,
        'employees':    employees,
    })


@login_required
@role_required('HR')
def mark_attendance(request):
    """HR: mark or update attendance for an employee on a date."""
    employees = Employee.objects.all()

    if request.method == 'POST':
        employee_id = request.POST.get('employee')
        date_str    = request.POST.get('date')
        status      = request.POST.get('status')

        employee = get_object_or_404(Employee, id=employee_id)
        try:
            from datetime import date
            att_date = date.fromisoformat(date_str)
        except (ValueError, TypeError):
            messages.error(request, 'Invalid date.')
            return render(request, 'mark_attendance.html', {'employees': employees})

        obj, created = Attendance.objects.update_or_create(
            employee=employee,
            date=att_date,
            defaults={'status': status},
        )
        action = 'Marked' if created else 'Updated'
        messages.success(request, f'{action} attendance for {employee.name} on {att_date}.')
        return redirect('attendance_list')

    today = timezone.now().date()
    return render(request, 'mark_attendance.html', {
        'employees': employees,
        'today':     today,
    })
