from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os

def generate_payslip(payroll):
    file_path = f"payslip_{payroll.employee.id}_{payroll.month}_{payroll.year}.pdf"

    c = canvas.Canvas(file_path, pagesize=letter)

    c.drawString(200, 750, "PAYSLIP")

    c.drawString(50, 700, f"Employee: {payroll.employee.name}")
    c.drawString(50, 680, f"Month: {payroll.month}/{payroll.year}")

    c.drawString(50, 640, f"Basic Salary: {payroll.basic_salary}")
    c.drawString(50, 620, f"HRA: {payroll.hra}")
    c.drawString(50, 600, f"Bonus: {payroll.bonus}")

    c.drawString(50, 560, f"Deductions: {payroll.deductions}")
    c.drawString(50, 540, f"Net Salary: {payroll.net_salary}")

    c.save()

    return file_path