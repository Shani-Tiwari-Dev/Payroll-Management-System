from django.urls import path
from .views import payroll_list, generate_payroll, download_payslip

urlpatterns = [
    path('',                         payroll_list,     name='payroll_list'),
    path('generate/',                generate_payroll, name='generate_payroll'),
    path('payslip/<int:payroll_id>/', download_payslip, name='payslip'),
]
