from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import FileResponse
from accounts.views import role_required
from employees.models import Employee
from .models import Payroll
from .utils import generate_payslip


@login_required
@role_required('HR')
def payroll_list(request):
    payrolls = Payroll.objects.select_related('employee').order_by('-year', '-month')
    return render(request, 'payroll_list.html', {'payrolls': payrolls})


@login_required
@role_required('HR')
def generate_payroll(request):
    employees = Employee.objects.all()
    if request.method == 'POST':
        emp_id = request.POST.get('employee')
        month  = request.POST.get('month')
        year   = request.POST.get('year')
        employee = get_object_or_404(Employee, id=emp_id)
        obj, created = Payroll.objects.update_or_create(
            employee=employee,
            month=int(month),
            year=int(year),
            defaults={
                'basic_salary': employee.basic_salary,
                'hra':          employee.hra,
                'bonus':        employee.bonus,
            }
        )
        messages.success(request, f'Payroll {"generated" if created else "updated"} for {employee.name}.')
        return redirect('payroll_list')
    from django.utils import timezone
    today = timezone.now()
    return render(request, 'generate_payroll.html', {
        'employees': employees,
        'current_month': today.month,
        'current_year':  today.year,
    })


@login_required
def download_payslip(request, payroll_id):
    payroll = get_object_or_404(Payroll, id=payroll_id)
    # Employees can only download their own payslip
    profile = request.user.userprofile
    if profile.role == 'EMPLOYEE':
        if not profile.employee or profile.employee.id != payroll.employee.id:
            from django.http import HttpResponseForbidden
            return HttpResponseForbidden('Not your payslip.')
    file_path = generate_payslip(payroll)
    return FileResponse(open(file_path, 'rb'), as_attachment=True)
